package com.conneqt.tvChannelApp.services;

import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.conneqt.tvChannelApp.model.Channel;
import com.conneqt.tvChannelApp.repository.ChannelRepository;

public class ChannelServiceTest {
	@Autowired
	private ChannelService channelService;
		
	@MockBean
	private ChannelRepository channelRepository;
	
	@BeforeEach
	void setup() {
		Optional<Channel> channel=Optional.of(new Channel(Long.valueOf(1),"India TV",Double.valueOf(50),"Hindi"));
		Mockito.when(channelRepository.findById(Long.valueOf(1))).thenReturn(channel);
		Channel channels=new Channel(null, "NDTV",Double.valueOf(99),"English");
		Mockito.when(channelRepository.save(channels)).thenReturn(channel.get());
	}
	
	
	/*
	 * @Test void testGetChannelById() { String channel_Name="NDTV"; Channel
	 * channelById=channelService.getChannelById(Long.valueOf(1));
	 * assertEquals(channelById.getChannelName()); }
	 */


}
