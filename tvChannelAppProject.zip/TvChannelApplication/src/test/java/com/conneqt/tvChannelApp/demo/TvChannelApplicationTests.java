package com.conneqt.tvChannelApp.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TvChannelApplicationTests {

	@Test
	void contextLoads() {
	}

}
