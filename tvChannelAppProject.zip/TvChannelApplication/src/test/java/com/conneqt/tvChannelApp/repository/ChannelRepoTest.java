package com.conneqt.tvChannelApp.repository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;

import com.conneqt.tvChannelApp.model.Channel;



@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class ChannelRepoTest {
	@Autowired
	ChannelRepository channelRepository;
	@Autowired
	private TestEntityManager entityManager;
	
	@BeforeEach
	void setup() {
		Channel channel=new Channel(Long.valueOf(1),"NDTV",Double.valueOf(99),"English");
		entityManager.detach(channel);;
	}
	/*
	 * @Test public void testFindById() { Channel
	 * channel=channelRepository.findById(Long.valueOf(1)).get();
	 * assertEquals("NDTV", channel.getChannelName());
	 * 
	 * }
	 */

}

