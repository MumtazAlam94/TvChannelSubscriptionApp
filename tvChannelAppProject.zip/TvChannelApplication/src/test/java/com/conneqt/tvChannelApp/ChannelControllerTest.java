package com.conneqt.tvChannelApp;

import org.junit.jupiter.api.BeforeEach;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.conneqt.tvChannelApp.controller.ChannelController;
import com.conneqt.tvChannelApp.model.Channel;
import com.conneqt.tvChannelApp.services.ChannelService;

@WebMvcTest(ChannelController.class)
class ChannelControllerTest {
	@Autowired
	private MockMvc mockMvc;
	@MockBean
	private ChannelService channelService;

	private Channel channel;

	@BeforeEach
	void setup() {
		channel = new Channel(Long.valueOf(1), "NDTV", Double.valueOf(99), "English");
	}
}
