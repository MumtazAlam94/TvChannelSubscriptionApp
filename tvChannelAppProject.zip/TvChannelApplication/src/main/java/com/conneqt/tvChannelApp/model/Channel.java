package com.conneqt.tvChannelApp.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@RequiredArgsConstructor
@Entity
@Table
public class Channel {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long channelId;
	@Column
    private String channelName;
	@Column
    private double cost;
	@Column
    private String language;
	
	public Channel(Long channelId, String channelName, double cost, String language) {
		super();
		this.channelId = channelId;
		this.channelName = channelName;
		this.cost = cost;
		this.language = language;
	}

}
