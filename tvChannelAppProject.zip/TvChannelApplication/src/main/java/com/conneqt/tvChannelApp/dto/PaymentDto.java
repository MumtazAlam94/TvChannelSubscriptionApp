package com.conneqt.tvChannelApp.dto;

import java.time.LocalDateTime;

import com.conneqt.tvChannelApp.model.User;

public class PaymentDto {
	
	private Long id;
	
	private User user;
	
	private double amount;
	 
	private LocalDateTime paymentDate;

	public PaymentDto() {

	}

	public PaymentDto(Long id, User user, double amount, LocalDateTime paymentDate) {
		super();
		this.id = id;
		this.user = user;
		this.amount = amount;
		this.paymentDate = paymentDate;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public LocalDateTime getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(LocalDateTime paymentDate) {
		this.paymentDate = paymentDate;
	}

}
