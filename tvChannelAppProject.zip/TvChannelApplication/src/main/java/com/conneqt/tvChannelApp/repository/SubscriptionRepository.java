package com.conneqt.tvChannelApp.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.conneqt.tvChannelApp.model.Subscription;

@Repository
@Transactional
public interface SubscriptionRepository extends JpaRepository<Subscription, Long> {
   // List<Subscription> findByUser(User user);
	
	
	  @Query(value="SELECT * FROM SUBSCRIBE S WHERE S.USER_ID =:userId")
	  List<Subscription> findAllSubscribtionByUserId(Long userId);
	 

}