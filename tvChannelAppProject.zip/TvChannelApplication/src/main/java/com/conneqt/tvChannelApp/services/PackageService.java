package com.conneqt.tvChannelApp.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.conneqt.tvChannelApp.model.Packages;
import com.conneqt.tvChannelApp.repository.PackageRepository;

@Service
public class PackageService {
	@Autowired
    private PackageRepository packageRepository;
	
	public List<Packages> getAllPackage() {
		List<Packages> packages = packageRepository.findAll();
		return packages;
	}

	public Packages addNewPackage(Packages packages) {
		Packages savepackages = packageRepository.save(packages);
		return savepackages;
	}

	

    
}
