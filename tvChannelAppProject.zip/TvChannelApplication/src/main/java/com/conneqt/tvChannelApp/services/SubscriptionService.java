package com.conneqt.tvChannelApp.services;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.conneqt.tvChannelApp.model.Channel;
import com.conneqt.tvChannelApp.model.Plan;
import com.conneqt.tvChannelApp.model.Subscription;
import com.conneqt.tvChannelApp.model.User;
import com.conneqt.tvChannelApp.repository.PlanRepository;
import com.conneqt.tvChannelApp.repository.SubscriptionRepository;
import lombok.extern.log4j.Log4j2;

@Service
@Log4j2
public class SubscriptionService {
	@Autowired
    private SubscriptionRepository subscriptionRepository;
	
	@Autowired
	PlanRepository planRepository;

	/*
	 * public Subscription subscribe(Long userId, Long channelId) {
	 * return null; // Implement subscription logic }
	 */
    public Subscription createNewSubscription(Subscription subscriptions) {
    	// Implement subscription creation logic
    	Subscription subscription = new Subscription();
		LocalDateTime localdate = LocalDateTime.now();
		subscription.setStartDate(localdate);
		Optional<Plan> plan = planRepository.findById(subscriptions.getPlan().getPlanId());
		if (plan.isPresent())
			subscription.setEndDate(localdate.plusMonths(plan.get().getDurationMonths()));
		else
			throw new RuntimeException("Plan not found Exception");
		
		Subscription subscribes = subscriptionRepository.save(subscriptions);
		return subscribes;
		
		
    }

    //public List<Channel> getUserSubscribedChannels(User user) {
    	
    	public List<Subscription> getUserSubscribedChannels(Long userId) {
    		List<Subscription> subscribes = subscriptionRepository.findAllSubscribtionByUserId(userId);
    		log.info("getAllSubscribtionBasedOnUserId()-> Get the subscription for userId :"+userId);
    		return subscribes;
    	}
    	
    	public List<Subscription> getAllSubscribe() {
    		List<Subscription> subscription = subscriptionRepository.findAll();
    		return subscription;
    	}
}
    
