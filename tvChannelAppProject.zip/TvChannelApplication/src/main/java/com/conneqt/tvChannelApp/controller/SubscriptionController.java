package com.conneqt.tvChannelApp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.conneqt.tvChannelApp.model.Channel;
import com.conneqt.tvChannelApp.model.Subscription;
import com.conneqt.tvChannelApp.services.SubscriptionService;

import lombok.extern.log4j.Log4j2;

@RestController
@Log4j2
@RequestMapping("/api/subscriptions")
public class SubscriptionController {
	
	@Autowired
    private SubscriptionService subscriptionService;
    
    
    @GetMapping("/getallsubscribe")
	public ResponseEntity<List<Subscription>> getAllSubscribe() {
		List<Subscription> subscriptin = subscriptionService.getAllSubscribe();
		log.info("SubscribeController -> subscription Data fetched succesfully");
		return new ResponseEntity<List<Subscription>>(subscriptin, HttpStatus.OK);
	}

	@GetMapping("/getallsubscriptionbyuserid")
	
	public ResponseEntity<List<Subscription>> getAllSubscribtionByUserId(@RequestParam Long userId) {
		List<Subscription> subscription = subscriptionService.getUserSubscribedChannels(userId);
		log.info("SubscribeController -> Subscription Data fetched succesfully for userId :"+userId);
		return new ResponseEntity<List<Subscription>>(subscription, HttpStatus.OK);
	}

	@PostMapping("/api/private/addsubscribtion")
	
	public ResponseEntity<Subscription> addSubscribtion(@RequestBody Subscription subscription) {
		Subscription subscribes = subscriptionService.createNewSubscription(subscription);
		log.info("SubscribeController -> User "+subscribes.getUser().getUserId()+" have subscribed Subscription the subscription succesfully");
		return new ResponseEntity<Subscription>(subscribes, HttpStatus.OK);
	}
    

    // Implement other subscription-related endpoints (unsubscribe, check subscription, etc.)
}

