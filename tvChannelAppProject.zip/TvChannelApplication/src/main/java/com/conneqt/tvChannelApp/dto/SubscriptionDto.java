package com.conneqt.tvChannelApp.dto;

import com.conneqt.tvChannelApp.model.Plan;
import com.conneqt.tvChannelApp.model.User;

public class SubscriptionDto {
	
	private Long id;
	
	private String subscriptionName;
	 
	private Package defaultPackage;
	 
	private Plan plan;
	
	private User user;
	
	private Package addOnPackage;
	
	private Integer subscriptionPeriod;
	
	private String duration;

	public SubscriptionDto() {
		
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getSubscriptionName() {
		return subscriptionName;
	}

	public void setSubscriptionName(String subscriptionName) {
		this.subscriptionName = subscriptionName;
	}

	public Package getDefaultPackage() {
		return defaultPackage;
	}

	public void setDefaultPackage(Package defaultPackage) {
		this.defaultPackage = defaultPackage;
	}

	public Plan getPlan() {
		return plan;
	}

	public void setPlan(Plan plan) {
		this.plan = plan;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Package getAddOnPackage() {
		return addOnPackage;
	}

	public void setAddOnPackage(Package addOnPackage) {
		this.addOnPackage = addOnPackage;
	}

	public Integer getSubscriptionPeriod() {
		return subscriptionPeriod;
	}

	public void setSubscriptionPeriod(Integer subscriptionPeriod) {
		this.subscriptionPeriod = subscriptionPeriod;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public SubscriptionDto(Long id, String subscriptionName, Package defaultPackage, Plan plan, User user,
			Package addOnPackage, Integer subscriptionPeriod, String duration) {
		super();
		this.id = id;
		this.subscriptionName = subscriptionName;
		this.defaultPackage = defaultPackage;
		this.plan = plan;
		this.user = user;
		this.addOnPackage = addOnPackage;
		this.subscriptionPeriod = subscriptionPeriod;
		this.duration = duration;
	}

}
