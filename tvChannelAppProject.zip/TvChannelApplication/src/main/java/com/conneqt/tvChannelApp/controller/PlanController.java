package com.conneqt.tvChannelApp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.conneqt.tvChannelApp.model.Plan;
import com.conneqt.tvChannelApp.services.PlanService;

@RestController
@RequestMapping("/api/plans")
public class PlanController {
	@Autowired
    private PlanService planService;
	
	
	@GetMapping("/getallplan")
	public ResponseEntity<List<Plan>> getAllPlans() {
		List<Plan> plans = planService.getAllPlans();
		return new ResponseEntity<List<Plan>>(plans, HttpStatus.OK);

	}

	@PostMapping("/addPlan")
	public ResponseEntity<Plan> addNewPlan(@RequestBody Plan plan) {
		Plan pln = planService.addNewPlan(plan);
		return new ResponseEntity<Plan>(pln, HttpStatus.OK);
	}

    
}
