package com.conneqt.tvChannelApp.dto;

import java.util.List;

import com.conneqt.tvChannelApp.model.Channel;

public class PackagesDto {
	
	 private Long id;
	 
	 private String packageName;
	 
	 public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPackageName() {
		return packageName;
	}

	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}

	public List<Channel> getChannels() {
		return channels;
	}

	public void setChannels(List<Channel> channels) {
		this.channels = channels;
	}

	private List<Channel> channels;

	public PackagesDto() {
		
	}

	public PackagesDto(Long id, String packageName, List<Channel> channels) {
		super();
		this.id = id;
		this.packageName = packageName;
		this.channels = channels;
	}

}
