package com.conneqt.tvChannelApp.model;

import java.time.LocalDateTime;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table
public class Subscription {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long subscriptionId;
    @Column
    private String subscriptionName;
    
    @ManyToOne(targetEntity = Package.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "packageId") 
    private Package addOnPackage;
    
    @ManyToOne(targetEntity = Channel.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "addonChannelId")
	private Channel addonChannel;
    
    @ManyToOne(targetEntity = Plan.class, fetch = FetchType.EAGER)
	@JoinColumn(name = "planId")
	private Plan plan;
    
    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.DETACH)
	@JoinColumn(name = "userId")
    private User user;
    
    @JsonFormat(pattern = "dd-MM-yyyy HH:mm:ss")
	private LocalDateTime startDate;
	@JsonFormat(pattern = "dd-MM-yyyy HH:mm:ss")
	private LocalDateTime endDate;
}
