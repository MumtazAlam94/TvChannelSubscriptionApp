package com.conneqt.tvChannelApp.services;

import org.springframework.security.core.userdetails.UserDetailsService;
import com.conneqt.tvChannelApp.dto.UserRegistrationDto;
import com.conneqt.tvChannelApp.model.User;

public interface UserService extends UserDetailsService{
	User save(UserRegistrationDto registrationDto);
}
