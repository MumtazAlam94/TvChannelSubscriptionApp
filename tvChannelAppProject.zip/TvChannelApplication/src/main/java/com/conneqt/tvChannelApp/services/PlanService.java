package com.conneqt.tvChannelApp.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.conneqt.tvChannelApp.model.Plan;
import com.conneqt.tvChannelApp.repository.PlanRepository;

@Service
public class PlanService {
	@Autowired
    private PlanRepository planRepository;
	
	public List<Plan> getAllPlans(){
		return planRepository.findAll();		
	}
	public Plan addNewPlan(Plan plan){
		return planRepository.save(plan);		
	}

    
}