package com.conneqt.tvChannelApp.dto;

public class PlanDto {
	
	private Long id;
	
	private String planName;
	 
	private Double cost;
	
	private int durationMonths;

	public PlanDto() {
		
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public Double getCost() {
		return cost;
	}

	public void setCost(Double cost) {
		this.cost = cost;
	}

	public int getDurationMonths() {
		return durationMonths;
	}

	public void setDurationMonths(int durationMonths) {
		this.durationMonths = durationMonths;
	}

	public PlanDto(Long id, String planName, Double cost, int durationMonths) {
		super();
		this.id = id;
		this.planName = planName;
		this.cost = cost;
		this.durationMonths = durationMonths;
	}

}
