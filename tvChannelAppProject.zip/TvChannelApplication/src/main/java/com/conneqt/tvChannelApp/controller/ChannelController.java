package com.conneqt.tvChannelApp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.conneqt.tvChannelApp.model.Channel;
import com.conneqt.tvChannelApp.services.ChannelService;

@RestController
@RequestMapping("/api/channels")
public class ChannelController {
	@Autowired
    private ChannelService channelService;

    @GetMapping("/getallchannel")
    public List<Channel> getAllChannels() {
        return channelService.getAllChannels();
    }
    
    @PostMapping("/addchannel")
	public Channel addChannel(@RequestBody Channel channel){
    	return channelService.addNewChannels(channel);
	}

}
