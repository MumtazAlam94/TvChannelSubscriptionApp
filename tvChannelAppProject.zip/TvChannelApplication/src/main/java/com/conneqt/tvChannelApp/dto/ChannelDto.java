package com.conneqt.tvChannelApp.dto;



public class ChannelDto {
	
	
    private Long channelId;
	
    private String channelName;
	
    private double cost;
	
    private String language;

	public Long getChannelId() {
		return channelId;
	}

	public void setChannelId(Long channelId) {
		this.channelId = channelId;
	}

	public String getChannelName() {
		return channelName;
	}

	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}

	public double getCost() {
		return cost;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public ChannelDto() {
		
	}

	public ChannelDto(Long channelId, String channelName, double cost, String language) {
		super();
		this.channelId = channelId;
		this.channelName = channelName;
		this.cost = cost;
		this.language = language;
	}


}
