package com.conneqt.tvChannelApp.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table
public class Packages {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long packageId;
    @Column
    private String packageName;
    
    @ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.DETACH)
	@JoinTable(name = "PACK_CHANNEL", joinColumns = { @JoinColumn(name = "PACKAGE_ID") }, inverseJoinColumns = {
			@JoinColumn(name = "CHANNEL_ID") })
    private List<Channel> channels;

}