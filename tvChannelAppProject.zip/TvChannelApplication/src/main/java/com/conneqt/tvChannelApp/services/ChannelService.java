package com.conneqt.tvChannelApp.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.conneqt.tvChannelApp.model.Channel;
import com.conneqt.tvChannelApp.repository.ChannelRepository;

@Service
public class ChannelService {
	@Autowired
    private ChannelRepository channelRepository;

	
	  public List<Channel> getAllChannels() {
		  return channelRepository.findAll();
	}
	  
	  public Channel getChannelById(Long channelId) { 
		 return channelRepository.findById(channelId).orElse(null);
	}
	  
	  public Channel addNewChannels(Channel channel) {
			return channelRepository.save(channel);
   }
	 

}